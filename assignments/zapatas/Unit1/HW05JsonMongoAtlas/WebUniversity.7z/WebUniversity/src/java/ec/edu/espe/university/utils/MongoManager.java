package ec.edu.espe.university.utils;

import com.google.gson.Gson;
import java.net.UnknownHostException;

import com.google.gson.Gson;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.net.UnknownHostException;
import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.UpdateResult;
import java.util.Properties;
import org.bson.Document;

public class MongoManager  {
    
    public boolean save(String data){
        MongoClientURI uri = new MongoClientURI(
        "mongodb+srv://christopher:Ligobas1209@cluster0.qfcgzcm.mongodb.net/?retryWrites=true&w=majority"); 
        
        MongoClient mongoClient = new MongoClient(uri);
        MongoDatabase database = mongoClient.getDatabase("test");
        MongoCollection collection = database.getCollection("University");
        Document productregistry = null;
        boolean saved = false;
        try{
            productregistry = Document.parse(data);  
            saved = true;
        }
        catch(Exception e){
            saved = false;
        }

        collection.insertOne(productregistry);
        mongoClient.close();   
        return saved;
    }
    
    public static String find(String nameToFind){
        try {
            MongoClientURI uri = new MongoClientURI(
            "mongodb+srv://sebastian:Lordalexander213@cluster0.qfcgzcm.mongodb.net/?retryWrites=true&w=majority"); 
            MongoClient mongoClient = new MongoClient(uri);
            MongoDatabase database = mongoClient.getDatabase("test");
            MongoCollection collection = database.getCollection("University");
            Document found = (Document) collection.find(Filters.eq("id",nameToFind)).first();
            if(found!=null){
                System.out.println("Data found");
                System.out.println(found.toString());   
                mongoClient.close();
                return (found.toJson());
            }
            else{
                System.out.println("Not found");
                mongoClient.close();   
                return "null";
            }
        }
        catch (Exception e){
            System.out.println("Find Error..");
            return "null";
        }        
    }
    
    public  boolean delete(String table,String name){
             try {
            MongoClientURI uri = new MongoClientURI(
            "mongodb+srv://dbChris:inventory123@proyect1.jfdts.mongodb.net/Proyect1?retryWrites=true&w=majority"); 
            MongoClient mongoClient = new MongoClient(uri);
            MongoDatabase database = mongoClient.getDatabase("test");
            MongoCollection collection = database.getCollection("Example");
            Document found = (Document) collection.find(Filters.eq("name",name)).first();
            if(found!=null){
                collection.deleteOne(Filters.eq("name",name)); 
                mongoClient.close();                
               return true;
            }
            else{
                mongoClient.close();   
                return false;
            }
        }
        catch (Exception e){
               System.out.println("No funciono el delete"); 
               return false;
        }
    }

    public void updateName(String nameToChange,String nameToUpdate){
            try{
            MongoClientURI uri = new MongoClientURI(
            "mongodb+srv://dbChris:inventory123@proyect1.jfdts.mongodb.net/Proyect1?retryWrites=true&w=majority"); 
            MongoClient mongoClient = new MongoClient(uri);
            MongoDatabase database = mongoClient.getDatabase("test");
            MongoCollection<Document> collection = database.getCollection("Example"); 
            Document firstDocument;
            firstDocument = collection.find().filter(Filters.eq("name", nameToChange)).first();           
            firstDocument.replace("name",nameToUpdate);
            collection.replaceOne(Filters.gte("name",nameToChange), firstDocument);
            mongoClient.close();
            }
            catch(Exception e){
                System.out.println("Update name ERROR");
            }
            
    }

    public static void updateBrand(String name,String newBrand){
        try{
            MongoClientURI uri = new MongoClientURI(
            "mongodb+srv://dbChris:inventory123@proyect1.jfdts.mongodb.net/Proyect1?retryWrites=true&w=majority"); 
            MongoClient mongoClient = new MongoClient(uri);
            MongoDatabase database = mongoClient.getDatabase("test");
            MongoCollection<Document> collection = database.getCollection("Example"); 
            Document firstDocument;
            firstDocument = collection.find().filter(Filters.eq("name", name)).first();           
            firstDocument.replace("brand",newBrand);           
            collection.replaceOne(Filters.gte("name",name), firstDocument);
            mongoClient.close();
        }
        catch(Exception e){
            System.out.println("Update brand error");
        }
    }

     public static void updateQuantity(String name,int newQuantity){
        try{
            MongoClientURI uri = new MongoClientURI(
            "mongodb+srv://dbChris:inventory123@proyect1.jfdts.mongodb.net/Proyect1?retryWrites=true&w=majority"); 
            MongoClient mongoClient = new MongoClient(uri);
            MongoDatabase database = mongoClient.getDatabase("test");
            MongoCollection<Document> collection = database.getCollection("Example"); 
            Document firstDocument;
            firstDocument = collection.find().filter(Filters.eq("name",name)).first();           
            firstDocument.replace("quantity",newQuantity);           
            collection.replaceOne(Filters.gte("name",name), firstDocument);
            mongoClient.close();
        }
        catch(Exception e){
            System.out.println("Update Quantity error");
        }

    }   

    public boolean update(String table, String dataToUpdate, String finder) {
        throw new UnsupportedOperationException("Not supported yet."); 
}

